package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexao {
	//Propriedade prop;

	 
	public static  String sql;
	   
	public static  String server232 = "10.70.33.232";
	public static  String server222 = "AZ2D-MASKDB-222.DEVCDT.COM.BR";
	public static  String port = "1433";               
	public static  String database = "BMG";
	public static  String database2 = "bmg_noname_hmlg";

      // Configuracao dos parametros de autenticacao
	public static  String user = "UserPier";
	public static String passwd = "UserPier";
	
	public String getUrl() {
		return url;
	}

	public String getDriver() {
		return driver;
	}

	public void setUrl(String url) {
		Conexao.url = url;
	}

	public void setDriver(String driver) {
		Conexao.driver = driver;
	}

	public static String url = "jdbc:sqlserver://" + server232 + ":" + port + ";database=" + database;
    public static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDataSource";
    
    public static void atualizarStatusLote() throws ClassNotFoundException, SQLException {
		Class.forName(driver);	
        Connection con = DriverManager.getConnection(url, user, passwd);
        Statement stmt = con.createStatement();
        Integer idLote = 99999;
		sql = 	  "UPDATE Lotes"
        		+ "SET StatusLote = 1 "
        		+ "WHERE id_Lote  = "  + idLote  + "";
	    stmt.executeQuery(sql);
        con.close();
	}
    
    public static Connection criarConexao() throws ClassNotFoundException, SQLException {
    	  Class.forName(driver);	
          Connection con = DriverManager.getConnection(url, user, passwd);
          return con;
    }
    
    public static void encerraConexao(Statement stmt) throws SQLException {
    	stmt.close();
    }
	
/*	public static void main(String[] args) {
        String sql;
   
        String server = "10.60.30.23";
        String port = "1433";               
        String database = "Valhalla";

        // Configuracao dos parametros de autenticacao
        String user = "UserValhalla";
        String passwd = "UserValhalla";

        try {
        //dataSource.setUrl("jdbc:sqlserver://10.60.30.23:1433;user=UserValhalla;password=UserValhalla");
        	String url = "jdbc:sqlserver://" + server + ":" + port + ";database=" + database;
            String driver = "com.microsoft.sqlserver.jdbc.SQLServerDataSource";

            // Abre-se a conex�o com o Banco de Dados
            Class.forName(driver);	
            Connection con = DriverManager.getConnection(url, user, passwd);

            // Cria-se Statement com base na conexao
            Statement stmt = con.createStatement();

            // Exemplo: navegando e exibindo os dados
            sql = Queries.BUSCAR_DADOS_REDUCAO;

            // Executa-se a consulta dos campos 
            ResultSet res = stmt.executeQuery(sql);
            
            Integer idBaseDados;
            String baseDados;
            String servidor;
            String usuario;

            while (res.next()) {
            	idBaseDados = res.getInt("idBaseDados");
            	baseDados = res.getString("Base");
            	servidor = res.getString("servidor");
            	usuario = res.getString("usuario");
                System.out.println(  idBaseDados + " - "+ baseDados + " - "+ servidor  +" - "+ usuario);
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
}