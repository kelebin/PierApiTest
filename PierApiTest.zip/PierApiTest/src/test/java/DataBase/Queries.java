package DataBase;

public class Queries {

	public static String BUSCAR_DADOS_REDUCAO = ""
							+" SELECT  *"
							+" FROM ReducaoBase "
							+" WHERE processoId = ?" ;
}
