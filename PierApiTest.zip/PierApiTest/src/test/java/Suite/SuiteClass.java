package Suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import test.MiddlewareConta;
import test.MiddlewareContaNoName;


@RunWith(Suite.class)
@SuiteClasses({
    MiddlewareConta.class,
    MiddlewareContaNoName.class
     })
public class SuiteClass {
	  
   
	

}
