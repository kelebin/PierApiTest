package Utils;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
	
	private static ExtentReports extent;
	private static Map<Integer, ExtentTest> exMap = new HashMap<Integer, ExtentTest>();
	private static String reportFileName = "ExtentReports-Version4-Test-Report.html";
	private static String path = System.getProperty("user.dir") + "\\TestReport";
	private static String reportFileLocation = path + "\\" + reportFileName;

	public static ExtentReports getInstance() {
		if(extent == null) {
			createInstance();
		}
		return extent;
	}

	public static ExtentReports createInstance() {
		String fileName = getReportFileLocation();
		
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setDocumentTitle(fileName);
		htmlReporter.config().setEncoding("utf-8");
		htmlReporter.config().setReportName(fileName);
		
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		
		try {
			extent.setSystemInfo("Hostname", InetAddress.getLocalHost().getHostName());
			extent.setSystemInfo("IP Address", InetAddress.getLocalHost().getHostAddress());
			extent.setSystemInfo("OS", System.getProperty("os.name"));
			extent.setSystemInfo("Username", System.getProperty("user.name"));
			extent.setSystemInfo("Java Version", System.getProperty("java.version"));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		return extent;
	}
	
	private static String getReportFileLocation() {
		createReportPath(path);
		System.out.println("ExtentReport Path for WINDOWS: " + path + "\n");
		return reportFileLocation;
	}
	
	private static void createReportPath(String path) {
		File testDirectory = new File(path);
		if(!testDirectory.exists()) {
			if(testDirectory.mkdir()) {
				System.out.println("O diretório: " + path + "foi criado!");
			}else {
				System.out.println("Falha ao criar diretório: " + path);
			}
		}else {
			System.out.println("Diretório já existente: " + path);
		}
	}
	
	public static synchronized ExtentTest getTest() {
		return exMap.get((int) (long) Thread.currentThread().getId());
	}
	
	public static synchronized ExtentTest startTest(String testName) {
		ExtentTest test = extent.createTest(testName);
		exMap.put((int) (long) Thread.currentThread().getId(), test);
		return test;
	}
	
}