package Utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;

public class Log {

	private static final Logger aLogger = getLogger();
	private static final SimpleDateFormat aFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	public static void info(String pMensagem) {
		mensagem(getCabecalho("INFO") + pMensagem);
	}

	public static void database(String pMensagem, int linha) {
		mensagem(getCabecalho("MASSA") + "[" + linha + "] " + pMensagem);
	}

	public static void erro(String pMensagem) {
		mensagem(getCabecalho("ERRO") + pMensagem);
	}

	public static void alerta(String pMensagem) {
		mensagem(getCabecalho("ALERTA") + pMensagem);
	}

	private static void mensagem(String pMensagemFinal) {
		aLogger.info(pMensagemFinal);
	}

	private static String getCabecalho(String pTipo) {
		return String.format("[%s] [%s] ", aFormat.format(Calendar.getInstance().getTime()), pTipo);
	}

	public static void excecao(Exception vExcecao) {
		if (vExcecao != null) {
			StringBuilder vBuilder = new StringBuilder();
			vBuilder.append("[EXCE��O OCORRIDA] " + vExcecao.getMessage());
			vBuilder.append('\n');
			vBuilder.append('\n' + Utils.extrairStackTrace(vExcecao));
			vBuilder.append('\n');
			erro(vBuilder.toString());
		}
	}
	
	private static Logger getLogger() {
		return Logger.getLogger(Thread.currentThread().getStackTrace()[2].getClassName());
	}

}