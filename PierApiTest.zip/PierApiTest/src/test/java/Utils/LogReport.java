package Utils;

import com.aventstack.extentreports.Status;

public class LogReport {

	public static void info(Object object) {
		ExtentManager.getTest().log(Status.INFO, object.toString());
		Log.info(object.toString());
	}

	public static void request(Object object) {
		String msg = "REQUISICAO - " + object.toString();
		ExtentManager.getTest().log(Status.INFO, msg);
		Log.info(msg);
	}

	public static void erro(Object object) {
		ExtentManager.getTest().log(Status.ERROR, object.toString());
		Log.erro(object.toString());
	}
	
	public static void json(Object object) {
		ExtentManager.getTest().log(Status.INFO, "<pre>" + object.toString() + "</pre>");
		Log.info(object.toString());
	}
}