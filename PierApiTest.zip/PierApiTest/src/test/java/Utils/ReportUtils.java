package Utils;

public class ReportUtils {

	public static String formatarNomeMetodo(String nomeMetodo) {
		String[] arrayMetodo = new String[nomeMetodo.length()];

		for (int i = 0; i < nomeMetodo.length(); i++) {
			arrayMetodo[i] = nomeMetodo.substring(i, i + 1);
		}

		for (int j = 0; j < arrayMetodo.length; j++) {
			if (arrayMetodo[j].equals(arrayMetodo[j].toUpperCase())) {
				arrayMetodo[j] = " " + arrayMetodo[j];
			}
		}

		nomeMetodo = new String();
		for (String s : arrayMetodo) {
			nomeMetodo = nomeMetodo + s;
		}

		nomeMetodo = capitalize(nomeMetodo);
		return nomeMetodo;
	}

	private static String capitalize(final String line) {
		return Character.toUpperCase(line.charAt(0)) + line.substring(1);
	}

}