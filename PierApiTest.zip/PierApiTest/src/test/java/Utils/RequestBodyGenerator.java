package Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.mockito.Mockito;

import com.google.gson.Gson;

import sun.security.util.Length;

@SuppressWarnings("rawtypes")
public class RequestBodyGenerator {

	public static Map segundaVia (Object idCartao) {
		Map<String, Object> req = new LinkedHashMap<String, Object>();
		req.put("idCartao", idCartao);
		return req;
	}
	
	public static Map gerarMassaDeDados(int porcentagem, Map mapa, List lista) {
		Map<String, Object> req = new LinkedHashMap<String, Object>();
		req.put("percentualReducaoBase", porcentagem);
		req.put("contasPreservadas", lista);
		req.put("emailContato", EntityGenericUtil.getStringEmail());
		req.put("emissor", EntityGenericUtil.getString());
		req.put("baseDados", mapa);
		return req;
	}

	public static Map gerarDadosServidor() {
		Map<String, Object> reqBase = new LinkedHashMap<String, Object>();
		reqBase.put("servidor", "10.60.30.23");
		reqBase.put("base", "Valhalla");
		reqBase.put("usuario", "UserValhalla");
		reqBase.put("senha", "UserValhalla");
		return reqBase;
	}

	public static List gerarListaContas() {
		List<Integer> listaContas = new ArrayList<Integer>();
		listaContas.add(EntityGenericUtil.getInteger());
		listaContas.add(EntityGenericUtil.getInteger());
		listaContas.add(EntityGenericUtil.getInteger());
		return listaContas;
	}

	public static List gerarListaString() {
		List<String> listaContas = new ArrayList<String>();
		listaContas.add(EntityGenericUtil.getString());
		listaContas.add(EntityGenericUtil.getString());
		listaContas.add(EntityGenericUtil.getString());
		return listaContas;
	}
	
	public static Map gerarBodyCartao(Object idpessoa, Object idlote) {
		Map<String, Object> req = new LinkedHashMap<String, Object>();
		req.put("idPessoa", idpessoa);
		req.put("idLote", idlote);
		return req;
	}
	
	public static Map dadosLote(Integer tipolote, Integer qtdSolicitada,
			Integer idProduto, String dataAgendamento, Integer idSolicitante ) {
		Map<String, Object> req = new LinkedHashMap<String, Object>();
		req.put("tipoLote", tipolote );
		req.put("qtdSolicitada", qtdSolicitada);
		req.put("idProduto", idProduto);
		req.put("dataAgendamento", dataAgendamento);
		req.put("idSolicitante", idSolicitante);
		return req;
	}
	
	public static Map dadosMiddleware(Long idConta,Object funcaoAtiva,Long idCartao) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idConta", idConta );
		 req.put("funcaoAtiva", funcaoAtiva);
		 req.put("idCartaoAtual", idCartao);
		 return req;
	}
	
	public static Map MiddlewareCartoes (Object idproduto, Object qtd, Object ids) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idProduto", idproduto );
		 req.put("qtdSolicitada", qtd);
		 req.put("idSolicitante", ids);
		 return req;
	} 
	
	public static Map middlewareAtribuicao(Object a, Object b, Object c, Object d) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idCartao", a );
		 req.put("idPessoa", b);
		 req.put("idConta", c);
		 req.put("idProduto", d);
		 return req;
	}
	
	/*public static Map dadosBancariosConta() {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idConta", idConta );
		 req.put("funcaoAtiva", funcaoAtiva);
		 req.put("idCartaoAtual", idCartao);
		 return req;
	}*/
	
	public static Map enderecos() {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idTipoEndereco", 1 );
		 req.put("cep", "60743465");
		 req.put("logradouro", "GIRASSOL");
		 req.put("numero", 1707 );
		 req.put("complemento", "Banco BMG");
		 req.put("pontoReferencia", "");
		 req.put("bairro", "Valentina" );
		 req.put("cidade", "Belo Horizonte");
		 req.put("uf", "MG");
		 req.put("pais", "Brasil" );
		 req.put("enderecoCorrespondencia", true);
		 req.put("tempoResidenciaAnos", 2);
		 req.put("tempoResidenciaMeses", 0);
		 return req;
	}
	
	public static Map telefone() {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idTipoTelefone", 1 );
		 req.put("ddd", "031");
		 req.put("telefone", "32903154");
		 req.put("ramal", Mockito.anyString());
		 
		 
		 return req;
	}
	
	public static Map servicoConta(Object idTipoServico) {
		Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idTipoServico", idTipoServico );
		 return req;
	}
	
	public static Map cvv(Object idCartao, Object data) {
		Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("id_cartao", idCartao );
		 return req;
	}
	
	
	public static Map pessoaPersist(Object idProduto,Object funcAtiva, Object servicoConta ) {
		
		
		Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("nome", "Regina Annes Guimaraes" );
		 req.put("nomeMae", "Marina Annes Guimaraes" );
		 req.put("dataNascimento", "1953-05-27" );
		 req.put("sexo", "M" );
		 req.put("cpf", EntityGenericUtil.getLong(11).toString() );
		 req.put("numeroIdentidade", "M52405" );
		 req.put("orgaoExpedidorIdentidade", "SSP" );
		 req.put("unidadeFederativaIdentidade", "" );
		 req.put("dataEmissaoIdentidade", "2017-03-31" );
		 req.put("idEstadoCivil", 1 );
		 req.put("idProfissao", "" );
		 req.put("idNaturezaOcupacao", 0 );
		 req.put("idNacionalidade", 1);
		 req.put("naturalidadeCidade", "PALMACIA" );
		 req.put("naturalidadeEstado", "CE" );
		 req.put("grauInstrucao", "4" );
		 req.put("numeroDependentes", 0 );
		 req.put("nomePai", "PAI TESTE CONDUCTOR" );
		 req.put("chequeEspecial", 1 );
		 req.put("idOrigemComercial", 2 );
		 req.put("idProduto", idProduto );
		 req.put("numeroBanco", 318 );
		 req.put("numeroAgencia", 58 );
		 req.put("numeroContaCorrente", "49942078" );
		 req.put("email", "" );
		 req.put("diaVencimento", 28 );
		 req.put("nomeImpresso", "" );
		 req.put("nomeEmpresa", "" );
		 req.put("valorRenda", 0 );
		 req.put("canalEntrada", "CDTP004" );
		 req.put("valorPontuacao", 0 );
		 req.put("funcaoAtiva", funcAtiva );
		 req.put("matriculaProposta", "" );
		 req.put("telefones", telefone());
		 req.put("enderecos", enderecos());
		 req.put("limiteGlobal", 2000.0);
		 req.put("limiteMaximo", 0);
		 req.put("limiteParcelas", 0);
		 req.put("limiteConsignado", 0);
		
		
		 Map<String, Object> pessoaPersist = new LinkedHashMap<String, Object>();
		pessoaPersist.put("pessoaPersist", req);
		pessoaPersist.put("dadosBancariosConta", dadosBancariosConta2());
		pessoaPersist.put("servicosConta", servicoConta(servicoConta));
		 
		
		
		 return pessoaPersist; 
	}
	
	public static Map suspeitaFraude(Object a, Object b, Object c) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idMotivoFraude", a );
		 req.put("idPessoa", b);
		 req.put("dataHoraSuspeitaFraude", c);
		 return req;
	}
	
	
	public static Map pegarCartao(Object a) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idCartao", a );		
		 return req;
	}

	public static Map motivoDescricao(Object a) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("descricao", a );		
		 return req;
	}

	public static Map motivoDescricao2(Object a, Object b) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("descricao", a );		
		 req.put("id", b );	
		 return req;
	}
	
	public static Map dadosBancariosConta(Object idConta, Object numeroAgencia, Object numeroContaCorrente, Object codigoBanco, Object idTipoContaBancaria) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idConta", idConta );
		 req.put("numeroAgencia", numeroAgencia);
		 req.put("numeroContaCorrente", numeroContaCorrente);
		 req.put("codigoBanco", codigoBanco);
		 req.put("idTipoContaBancaria", idTipoContaBancaria);
		 return req;
	}
	
	public static Map dadosBancariosConta2() {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idConta", 0 );
		 req.put("numeroAgencia", 1);
		 req.put("numeroContaCorrente", "1000628");
		 req.put("codigoBanco", 318);
		 req.put("idTipoContaBancaria", 3);
		 return req;
	}
	
	public static Map segundaViaCartao(Object a, Object b, Object c,Object d) {
		 Map<String, Object> req = new LinkedHashMap<String, Object>();
		 req.put("idCartao", a );
		 req.put("idConta", b);
		 req.put("idPessoa", c);
		 req.put("idProduto", d);
		
		 return req;
	}
	
	/*public static Object gerarBodyCartaoM() {
		return gerarBodyCartao();
	}*/

	public static Object gerarDadosLote(String tipoLote) {
		return dadosLote(null, null, null, tipoLote, null);
	}
	
	public static Object gerarMassaDados() {
		return gerarMassaDeDados(EntityGenericUtil.getIntegerBase10(), gerarDadosServidor(), gerarListaContas());
	}

	public static Object geradorDadosListaVazia() {
		return gerarMassaDeDados(EntityGenericUtil.getIntegerBase10(), gerarDadosServidor(), Mockito.anyList());
	}

	public static Object geradorRequestMockadaListaString() {
		return gerarMassaDeDados(EntityGenericUtil.getIntegerBase10(), gerarDadosServidor(), gerarListaString());
	}

	public static Map geradorRequestMockadaPorcentagemInvalida() {
		return gerarMassaDeDados(-1, gerarDadosServidor(), gerarListaString());
	}

	public static Map geradorRequestMockadaPorcentagemNaoInformada() {
		return gerarMassaDeDados(Mockito.anyInt(), gerarDadosServidor(), gerarListaString());
	}

	public static Object gerarBodyVazio() {
		return Mockito.anyMap();
	}
	


}
