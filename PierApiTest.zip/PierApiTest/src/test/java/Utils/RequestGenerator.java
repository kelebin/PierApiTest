package Utils;

import static io.restassured.RestAssured.defaultParser;
import static io.restassured.RestAssured.given;

import java.util.Map;

import org.testng.annotations.Optional;

import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;

@SuppressWarnings("rawtypes")
public class RequestGenerator {
	  
	  public static final  String access_token = "access_token";
	
	  public Response genericRequestPOST(String token, Object body,String url, Integer status) {
	
	  defaultParser = Parser.JSON;	
	  
	  return   			        
	    		         given()
	    		         .log().all()
	    		         	  .header(access_token, token)
	    		         	  .relaxedHTTPSValidation()
	    		              .contentType(ContentType.JSON)
	    		              .body(body)
	    		         .when()
	    		              .post(url)
	    		         .then()
	    		         .log().all()
	    		              .statusCode(status) 
	    		              .contentType(ContentType.JSON)
	    		              .extract()
	    		              .response();
	    }
	  
	  public Response genericRequestPOST2(String token,String pathParam,Object pathValor,Object body,String url, Integer status) {
			
		  defaultParser = Parser.JSON;	
		  
		  
		  return   			        
		    		         given()
		    		         .log().all()
		    		         	  .header(access_token, token)
		    		         	 // .pathParam(pathParam.toString(), pathValor)
		    		         	  .relaxedHTTPSValidation()
		    		              .contentType(ContentType.JSON)
		    		              .body(body)
		    		         .when()
		    		              .post(url)
		    		         .then()
		    		         .log().all()
		    		              .statusCode(status) 
		    		              .contentType(ContentType.JSON)
		    		              .extract()
		    		              .response();
		    }
	  
	  public Response genericRequestGET(Object pathparamNome,Object pathPa, Object queryPa,String token,String url, Integer status) {
			
	    return
	    		         given()
	    		         .log().all()
		    		          .pathParam(pathparamNome.toString(), pathPa)
		    		          //.queryParam(qParam.toString(), queryPa)
		    		          .header(access_token, token)
		    		          .contentType(ContentType.JSON)
	    		         .when()
	    		              .get(url)
	    		         .then()
	    		         .log().all()
	    		              .statusCode(status) 
	    		              .contentType(ContentType.JSON)
	    		              .extract()
	    		              .response();
	
	    }
	  
	  public Response genericRequestGET2(String qParam,Object pathPa, Object queryPa,String token,String url, Integer status) {
			
		    return
		    		         given()
		    		         .log().all()
			    		          //.pathParam("id", pathPa)
			    		          .queryParam(qParam.toString(), queryPa)
			    		          .header(access_token, token)
			    		          .contentType(ContentType.JSON)
		    		         .when()
		    		              .get(url)
		    		         .then()
		    		         .log().all()
		    		              .statusCode(status) 
		    		              .contentType(ContentType.JSON)
		    		              .extract()
		    		              .response();
		
		    }
	  
	  public Response RequestGET(Object a, Object b,Object c,String token,String url, Integer status) {
			
		    return
		    		         given()
		    		         .log().all()
			    		          .pathParam("", "")
			    		          .header(access_token, token)
			    		          .contentType(ContentType.JSON)
		    		         .when()
		    		              .get(url)
		    		         .then()
		    		         .log().all()
		    		              .statusCode(status) 
		    		              .contentType(ContentType.JSON)
		    		              .extract()
		    		              .response();
		
		    }
	  
	  public Response genericRequestPUT(String token,String PathParamNome,Object PathParamValor,Map request,String url, Integer status) {
			 
	    	return		    
	    		         given()
	    		         	  .header(access_token, token)
	    		         	  .pathParam(PathParamNome.toString(), PathParamValor)
	    		              .contentType(ContentType.JSON)
	    		              .body(request)
	    		         .when()
	    		              .put(url)
	    		         .then()
	    		              .statusCode(status) 
	    		              .contentType(ContentType.JSON).extract().response();
	    
	    }
}
