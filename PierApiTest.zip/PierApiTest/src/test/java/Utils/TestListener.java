package Utils;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;

public class TestListener implements ISuiteListener, ITestListener, IInvokedMethodListener {

	private static ExtentReports extent;

	// Before Suite
	public void onStart(ISuite suite) {
		extent = ExtentManager.getInstance();
	}

	// Before Class
	public void onStart(ITestContext context) {

	}

	// Before Test
	public void onTestStart(ITestResult result) {
		ExtentManager.startTest(result.getMethod().getMethodName());
	}

	// Before Method
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		String methodName = method.getTestMethod().getMethodName();
		if(method.isTestMethod()) {
//			LogReport.info("[Iniciando o teste: " + ReportUtils.formatarNomeMetodo(methodName) + "]");
		}
	}

	// After Method
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {

	}

	public void onTestSuccess(ITestResult result) {
		ExtentManager.getTest().pass("Teste finalizado com sucesso!");
		Log.info("[Teste finalizado com sucesso]");
	}

	public void onTestFailure(ITestResult result) {
		ExtentManager.getTest().fail(result.getThrowable());
	}

	public void onTestSkipped(ITestResult result) {

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	// After Class
	public void onFinish(ITestContext context) {
		extent.flush();
	}

	// After Suite
	public void onFinish(ISuite suite) {

	}

}