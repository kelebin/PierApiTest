
package Utils;

public class UrlUtils {

	public static String urlReducao = "http://localhost:8080/v2/api-valhalla/reducaoBase/";
	
	public static String urlPedro = "http://10.5.3.202:8080/v2/api/lotes";
	
	public static String urlCassio = "http://10.5.3.164:8080/v2/api/lotes";
	
	public static String urlCassio2 = "http://10.5.3.183:8080/bmg-dev/lote-cartoes-noname";
	
	public static String urlCartoes = "http://10.5.3.99:8080/v2/api/contas/{id}/gerar-cartoes-lote";
	
	public static String urlFuncaoAtiva = "http://10.5.3.90:8080/bmg/funcaoAtiva";
	
	public static String HeimdallHML2 = "http://10.60.33.67:9091/qa/dados-bancarios-conta";
	
	public static String HeimdallHML = "http://10.60.33.67:9091/bmg-sbx/v1/contas";
	
	public static String HeimdallQuirino = "http://10.5.3.175:8080/bmg/contas";
	
	public static String HeimdallHML3 = "http://10.60.33.67:9091/bmg-hmlg-local/v1/contas";
	
	public static String HeimdallHMLQA = "http://10.60.33.67:9091/qa/contas";
	
	public static String HeimdallHMLQALotesCartao = "http://10.60.33.67:9091/qa/lote-cartoes-noname";
	
	public static String HeimdallHMLQALotes = "http://10.60.33.67:9091/qa/lotes";
	
	public static String HeimdallHMLQAAtribuir = "http://10.60.33.67:9091/qa/cartoes/atribuir";
	
	public static String MiddlewareBacana = "http://10.5.3.164:8080/bmg/lote-cartoes-noname";
	
	public static String PathSegundaVia = "http://10.60.33.71:7005/v2/api/cartoes/{id}/gerar-nova-via";
	
	public static String MiddlewareSegundaVia = "http://10.5.3.254:8080/gerarNovaViaPath/gerarNovaVia";
	
	public static String PathSegundaViaMultiplo = "http://10.60.33.71:7005/v2/api/cartoes/{id}/gerar-nova-via-multiplo";
	
	public static String xareu = "http://10.5.3.232:8181/v2/";
	
	public static String pierCartoes = "http://10.60.33.71:7005/v2/api/cartoes";
	
	public static String pierCartoesDadosReais = "http://10.60.33.71:7005/v2/api/cartoes/{id}/consultar-dados-reais";
	
	public static String token1 = "88bmg66BaseBMG";
	
	public static String token2 = "88bmgNN";
	
	public static String pierLote = "http://10.60.33.71:7005/v2/api/lotes";
	
	public static String pierMotFraude = "http://10.60.33.71:7005/v2/api/fraudes/motivos";
	
	public static String pierMotFraudePUT = "http://10.60.33.71:7005/v2/api/fraudes/motivos/{id}";
	
	public static String pierSusFraude = "http://10.60.33.71:7005/v2/api/fraudes/suspeitas";
	
	public static String getMetodoPierLoteC() {
		return urlCassio + "/tipos";
	}
	
	public static String getMetodoPierLoteP() {
		return urlPedro + "/tipos";
	}

	public static String getUrlReducaoNormal() {
		return urlReducao + "modoNormal";
	}

	public static String getUrlReducaoExtrema() {
		return urlReducao + "modoExtremo";
	}

	public static String getUrlReducaoRecuperacao() {
		return urlReducao + "modoRecuperacao";
	}


}