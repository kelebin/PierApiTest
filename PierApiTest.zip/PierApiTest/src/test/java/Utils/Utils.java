package Utils;

import io.restassured.response.Response;

public class Utils {
	
	public static String extrairStackTrace(Exception e) {
		StackTraceElement[] stack = e.getStackTrace();
		String exception = "";
		for (StackTraceElement s : stack) {
			exception = exception + s.toString() + "\n\t\t";
		}
		return exception;
	}
	
	public static void printResposta(Response response) {
		LogReport.info("***********************************  RESPOSTA  ***********************************");
		LogReport.info("[ source  : " + response.path("source") + " ]");
		LogReport.info("[ message : " + response.path("message") + " ]");
		LogReport.info("**********************************************************************************");
	}

}