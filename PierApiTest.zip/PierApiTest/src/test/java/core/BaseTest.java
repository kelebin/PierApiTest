package core;

import org.testng.annotations.Listeners;

import Utils.TestListener;

@Listeners(TestListener.class)
public class BaseTest {

}