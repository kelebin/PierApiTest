package test;

import org.junit.Test;

import Utils.EntityGenericUtil;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import validacao.validador;

public class BuscarLote {
	public RequestGenerator request = new RequestGenerator();

/*	public validador validador = new validador();
	@Test
	public void BuscarLotePorID() {
		try {
			// Response response =
			request.genericRequestGET("IdLote", "idLote", EntityGenericUtil.getToken(),
					UrlUtils.getMetodoPierLoteC(), 200);
		} catch (Exception e) {
		}
	}

	@Test
	public void BuscarLoteIdInexistente() {
		try {
			// Response response =
			request.genericRequestGET("idInexistente", "idInexistente",
					EntityGenericUtil.getToken(), UrlUtils.getMetodoPierLoteC(),
					404);
		} catch (Exception e) {
		}
	}
	
	@Test
	public void BuscarLoteSemInformarID() {
		try {
			// Response response =
			request.genericRequestGET("", "",
					EntityGenericUtil.getToken(), UrlUtils.getMetodoPierLoteC(),
					400);
		} catch (Exception e) {
		}
	}
	
	@Test
	public void BuscarLoteIdInvalido() {
		try {
			// Response response =
			request.genericRequestGET("idInvalido","idInvalido",
					EntityGenericUtil.getToken(), UrlUtils.getMetodoPierLoteC(),
					400);
		} catch (Exception e) {
		}
	}*/
}
