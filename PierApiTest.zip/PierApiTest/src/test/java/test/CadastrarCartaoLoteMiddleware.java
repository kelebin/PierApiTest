package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.response.Response;
import validacao.validador;

public class CadastrarCartaoLoteMiddleware extends BaseTest {
	public RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	
	@Test
	public void ct01MiddlewareGerarLoteBMGMais() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteBMGMais");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(532, 10, 1);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void ct02MiddlewareGerarLoteBMGMulti() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteBMGMulti");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(533, 10, 1);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void ct03MiddlewareGerarLoteBMGCard() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteBMGCard");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(531, 10, 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void ct04MiddlewareGerarLoteProdutoNaoPermite() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteProdutoNaoPermite");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(1, 1000, 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste");
			fail();
		}
	}
	
	@Test
	public void ct05MiddlewareGerarLoteProdutoInexistente() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteProdutoInexistente");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(666, 1000, 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void ct06MiddlewareGerarLoteProdutoInvalido() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteProdutoInvalido");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(-666, 1000, 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void ct07MiddlewareGerarLoteNaoInformarProduto() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteNaoInformarProduto");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(null, 1000, 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	}
	

	
	@Test
	public void ct10MiddlewareGerarLoteQuantidadeInvalida() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteQuantidadeInvalida");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(532, 0, 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
		//	//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void ct11MiddlewareGerarLoteQuantidadeNegativa() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteQuantidadeNegativa");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(532,-1 , 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void ct12MiddlewareGerarLoteNaoINformarQuantidade() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteNaoINformarQuantidade");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(532,null , 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	
	}
	
	@Test
	public void ct13MiddlewareGerarLoteIdSolicitanteInexistente() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteIdSolicitanteInexistente");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(532, 4000, "potato");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	
	}
	
	@Test
	public void ct14MiddlewareGerarLoteIdSolicitanteInvalido() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteIdSolicitanteInvalido");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(532, 4000, -999999);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	
	}
	
	@Test
	public void ct15MiddlewareGerarLoteIdSolicitanteNaoInformar() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteIdSolicitanteNaoInformar");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(532, 4000, null);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	
	}
	
	@Test
	public void ct16MiddlewareGerarLoteIdSolicitanteNaoInformarNenhumParametro() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteIdSolicitanteNaoInformarNenhumParametro");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(null, null, null);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
	
	}
	@Test
	public void ct17MiddlewareGerarLoteQuantidadeInvalidaNegativo() {
		try {
			LogReport.info("Iniciando o teste: MiddlewareGerarLoteBMGMais");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(531, "-5000" , 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
}
	
	@Test
	public void ct18MiddlewareGerarLoteQuantidadeAcimaDoMaximo() {
		try {
			LogReport.info("Iniciando o teste: ct18MiddlewareGerarLoteQuantidadeAcimaDoMaximo");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(531, 100001 , 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
}
	@Test
	public void ct19MiddlewareGerarLoteQuantidadeValorLimiteMenor() {
		try {
			LogReport.info("Iniciando o teste: ct18MiddlewareGerarLoteQuantidadeAcimaDoMaximo");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(531, 99999 , 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
}
	@Test
	public void ct20MiddlewareGerarLoteQuantidadeMuitoAcima() {
		try {
			LogReport.info("Iniciando o teste: ct18MiddlewareGerarLoteQuantidadeAcimaDoMaximo");
			Map dados = RequestBodyGenerator.MiddlewareCartoes(531, 1000000 , 1);
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHMLQALotes,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//	validador.validarDadosBanco(response);
		} catch (Exception e) {
			//LogReport.info("Erro no teste!");
			fail();
		}
}
}
