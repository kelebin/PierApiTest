package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.Test;
import org.mockito.Mockito;

import Utils.EntityGenericUtil;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import io.restassured.response.Response;
import validacao.validador;

public class CadastrarLote {
	public RequestGenerator request = new RequestGenerator();

/*	
	@Test
	public void BuscarLote() {
		try {
			
			request.genericRequestGET(2, "", EntityGenericUtil.getToken(), UrlUtils.urlCassio, 200);
			
			assertTrue(validador.validarBodyRequest(response, dados));
			validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}*/
	
	
	
	@Test
	public void GerarLoteBMGMais() {
		try {
			System.out.println("Iniciando o teste: GerarLoteBMGMais");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1, "2019-02-05T12:49:21.003Z", 123);
			Response response = request.genericRequestPOST(EntityGenericUtil.getToken(), dados, 
			UrlUtils.urlCassio,	201);
			assertTrue(validador.validarBodyRequest(response, dados));
			validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteBMGMultiplo() {
		try {
			System.out.println("Iniciando o teste: GerarLoteBMGMultiplo");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 2, "2019-02-05T12:49:21.003Z", 123);
		    Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,201);
			assertTrue(validador.validarBodyRequest(response, dados));
			validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteBMGCon() {
		try {
			System.out.println("Iniciando o teste: GerarLoteBMGCon");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 100, "2019-02-05T12:49:21.003Z", 123);
			Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,201);
			assertTrue(validador.validarBodyRequest(response, dados));
			validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteProdutoInexistente() {
		try {
			System.out.println("Iniciando o teste: GerarLoteProdutoInexistente");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 999, "2019-02-05T12:49:21.003Z", 123);
			Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
			assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteProdutoInvalido() {
		try {
			System.out.println("Iniciando o teste: GerarLoteProdutoInvalido");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, -1, "2019-02-05T12:49:21.003Z", 123);
			Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
			assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteSemINformarProduto() {
		try {
			System.out.println("Iniciando o teste: GerarLoteSemINformarProduto");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, null, "2019-02-05T12:49:21.003Z", 123);
			Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	//NO MIDDLEWARE PRECISA SER TRATADO!!!!!!!!
	@Test
	public void GerarLoteProdutoNULL() {
		try {
			System.out.println("Iniciando o teste: GerarLoteProdutoNULL");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, null, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,201);
				assertTrue(validador.validarBodyRequest(response, dados));
				validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLote10000() {
		try {
			System.out.println("Iniciando o teste: GerarLote10000");
			Map dados = RequestBodyGenerator.dadosLote(1, 10000, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,201);
				assertTrue(validador.validarBodyRequest(response, dados));
				validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLote1000() {
		try {
			System.out.println("Iniciando o teste: GerarLote1000");
			Map dados = RequestBodyGenerator.dadosLote(1, 1000, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,201);
				assertTrue(validador.validarBodyRequest(response, dados));
				validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLote1() {
		try {
			System.out.println("Iniciando o teste: GerarLote1");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,201);
				assertTrue(validador.validarBodyRequest(response, dados));
				validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteNegativo() {
		try {
			System.out.println("Iniciando o teste: GerarLote -1");
			Map dados = RequestBodyGenerator.dadosLote(1, -1, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteQuantidadeInvalida() {
		try {
			System.out.println("Iniciando o teste: GerarLoteQuantidadeInvalida");
			Map dados = RequestBodyGenerator.dadosLote(1, 0, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteSemInformarQtd() {
		try {
			System.out.println("Iniciando o teste: GerarLoteSemInformarQtd");
			Map dados = RequestBodyGenerator.dadosLote(1, null, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteTipoDeLoteDiferente() {
		try {
			System.out.println("Iniciando o teste: GerarLoteTipoDeLoteDiferente");
			Map dados = RequestBodyGenerator.dadosLote(2, 1, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteTipoLoteInexistente() {
		try {
			System.out.println("Iniciando o teste: GerarLoteTipoLoteInexistente");
			Map dados = RequestBodyGenerator.dadosLote(9, 1, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteTipoInvalido() {
		try {
			System.out.println("Iniciando o teste: GerarLoteTipoInvalido");
			Map dados = RequestBodyGenerator.dadosLote(-1, 1, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteSemINformarTipoLote() {
		try {
			System.out.println("Iniciando o teste: GerarLoteSemINformarTipoLote");
			Map dados = RequestBodyGenerator.dadosLote(Mockito.anyInt(), 1, 1, "2019-02-05T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteSolicitanteInvalido() {
		try {
			System.out.println("Iniciando o teste: GerarLoteSolicitanteInvalido");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1, "2019-02-05T12:49:21.003Z", -123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	//NO MIDDLEWARE PRECISA SER TRATADO!!!!!!!!
	@Test
	public void GerarLoteSolicitanteInexistente() {
		try {
			System.out.println("Iniciando o teste: GerarLoteSolicitanteInexistente");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1, "2019-02-05T12:49:21.003Z", 9999999);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,201);
				assertTrue(validador.validarBodyRequest(response, dados));
				validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteNaoInformarSolicitante() {
		try {
			System.out.println("Iniciando o teste: GerarLoteNaoInformarSolicitante");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1, "2019-02-05T12:49:21.003Z", null);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	//NO MIDDLEWARE PRECISA SER TRATADO!!!!!!!!
	@Test
	public void GerarLoteDataAgendamentoDiaAnterior() {
		try {
			System.out.println("Iniciando o teste: GerarLoteDataAgendamentoDiaAnterior");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1, "2019-02-04T12:49:21.003Z", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,201);
				assertTrue(validador.validarBodyRequest(response, dados));
				validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteDataAgendamentoInvalido() {
		try {
			System.out.println("Iniciando o teste: GerarLoteDataAgendamentoInvalido");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1, "2019-02-05", 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteDataAgendamentoNaoInformar() {
		try {
			System.out.println("Iniciando o teste: GerarLoteDataAgendamentoNaoInformar");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1,null, 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void GerarLoteDataAgendamentoNULL() {
		try {
			System.out.println("Iniciando o teste: GerarLoteDataAgendamentoNULL");
			Map dados = RequestBodyGenerator.dadosLote(1, 1, 1, null, 123);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),dados
					,UrlUtils.urlCassio,400);
				assertTrue(validador.validarBodyRequest(response, dados));
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
}
