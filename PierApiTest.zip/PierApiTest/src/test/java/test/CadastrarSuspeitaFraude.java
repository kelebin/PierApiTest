package test;

import static org.junit.Assert.fail;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.EntityGenericUtil;
import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.response.Response;
import validacao.validador;

public class CadastrarSuspeitaFraude extends BaseTest {
	private RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	//private Object ID_Pessoa = 4712877;

	
	@Test
	public void CT01_CadastrarFraude() {
		try {
			System.out.println("****Iniciando o teste: CT01_CadastrarFraude \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "2019-05-09T10:56:19.654Z");
			LogReport.info("Iniciando o teste: CT01_CadastrarFraude");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT02_CadastrarFraudeDataInválida() {
		try {
			System.out.println("****Iniciando o teste: CT02_CadastrarFraudeDataInválida \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude(1, 1, "2019-05-09");
			LogReport.info("Iniciando o teste: CT02_CadastrarFraudeDataInválida");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	
	@Test
	public void CT03_CadastrarFraudeDataFutura() {
		try {
			System.out.println("****Iniciando o teste: CT03_CadastrarFraudeDataFutura \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "2020-05-09T10:56:19.654Z");
			LogReport.info("Iniciando o teste: CT03_CadastrarFraudeDataFutura");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT04_CadastrarFraudeDataNull() {
		try {
			System.out.println("****Iniciando o teste: CT04_CadastrarFraudeDataNull \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude(1, 1,null);
			LogReport.info("Iniciando o teste: CT04_CadastrarFraudeDataNull");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	
	@Test
	public void CT05_CadastrarFraudeMotivoInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT05_CadastrarFraudeMotivoInvalido \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude("golfinho", 1, "2019-05-09T10:56:19.654Z");
			LogReport.info("Iniciando o teste: CT05_CadastrarFraudeMotivoInvalido");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT06_CadastrarFraudeMotivoInexistente() {
		try {
			System.out.println("****Iniciando o teste: CT06_CadastrarFraudeMotivoInexistente \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude(99, 1, "2019-05-09T10:56:19.654Z");
			LogReport.info("Iniciando o teste: CT06_CadastrarFraudeMotivoInexistente");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT07_CadastrarFraudeMotivoNULL() {
		try {
			System.out.println("****Iniciando o teste: CT07_CadastrarFraudeMotivoNULL \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude(null, 1, "2019-05-09T10:56:19.654Z");
			LogReport.info("Iniciando o teste: CT07_CadastrarFraudeMotivoNULL");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT08_CadastrarFraudeIdPessoaInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT08_CadastrarFraudeIdPessoaInvalido \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), "-123ABC", "2019-05-09T10:56:19.654Z");
			LogReport.info("Iniciando o teste: CT08_CadastrarFraudeIdPessoaInvalido");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT09_CadastrarFraudeIdPessoaInexistente() {
		try {
			System.out.println("****Iniciando o teste: CT09_CadastrarFraudeIdPessoaInexistente \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), -666, "2019-05-09T10:56:19.654Z");
			LogReport.info("Iniciando o teste: CT09_CadastrarFraudeIdPessoaInexistente");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT10_CadastrarFraudeIdPessoaNULL() {
		try {
			System.out.println("****Iniciando o teste: CT10_CadastrarFraudeIdPessoaNULL \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), null, "2019-05-09T10:56:19.654Z");
			LogReport.info("Iniciando o teste: CT10_CadastrarFraudeIdPessoaNULL");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT11_CadastrarFraudeSemParametros() {
		try {
			System.out.println("****Iniciando o teste: CT11_CadastrarFraudeSemParametros \n");
			//Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.suspeitaFraude(null, null, null);
			LogReport.info("Iniciando o teste: CT11_CadastrarFraudeSemParametros");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT12_CadastrarFraudeDataLimiteMax() {
		try {
			System.out.println("****Iniciando o teste: CT12_CadastrarFraudeDataLimiteMax \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "9999-12-31T23:59:59.999Z");
			LogReport.info("Iniciando o teste: CT12_CadastrarFraudeDataLimiteMax");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT13_CadastrarFraudeDataLimiteMin() {
		try {
			System.out.println("****Iniciando o teste: CT13_CadastrarFraudeDataLimiteMin \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "1753-01-01T00:00:00.000Z");
			LogReport.info("Iniciando o teste: CT13_CadastrarFraudeDataLimiteMin");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT14_CadastrarFraudeDataErrada() {
		try {
			System.out.println("****Iniciando o teste: CT14_CadastrarFraudeDataErrada \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "1753-02-30T00:00:00.000Z");
			LogReport.info("Iniciando o teste: CT14_CadastrarFraudeDataErrada");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT15_CadastrarFraudeDataAnoBissexto() {
		try {
			System.out.println("****Iniciando o teste: CT15_CadastrarFraudeDataAnoBissexto \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "2020-02-29T00:00:00.000Z");
			LogReport.info("Iniciando o teste: CT15_CadastrarFraudeDataAnoBissexto");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
		
	}
	@Test
	public void CT16_CadastrarFraudeDataAnoBissexto30() {
		try {
			System.out.println("****Iniciando o teste: CT16_CadastrarFraudeDataAnoBissexto30 \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "2020-02-30T00:00:00.000Z");
			LogReport.info("Iniciando o teste: CT16_CadastrarFraudeDataAnoBissexto30");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

}	
	@Test
	public void CT17_CadastrarFraudeDataAnoBissexto31() {
		try {
			System.out.println("****Iniciando o teste: CT17_CadastrarFraudeDataAnoBissexto31 \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "2020-02-31T00:00:00.000Z");
			LogReport.info("Iniciando o teste: CT17_CadastrarFraudeDataAnoBissexto31");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

}	
	@Test
	public void CT18_CadastrarFraudeDataAnoBissexto32() {
		try {
			System.out.println("****Iniciando o teste: CT18_CadastrarFraudeDataAnoBissexto32 \n");
			Object ID_Pessoa = validador.BuscarPessoa();
			dados = RequestBodyGenerator.suspeitaFraude(EntityGenericUtil.getIDMotivo(), ID_Pessoa, "2020-02-32T00:00:00.000Z");
			LogReport.info("Iniciando o teste: CT18_CadastrarFraudeDataAnoBissexto32");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST(UrlUtils.token2, dados,
					UrlUtils.pierSusFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

}	
}
