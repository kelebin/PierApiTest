package test;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.Assert;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.response.Response;
import validacao.validador;

public class CadastroMotivosFraude extends BaseTest {
	private RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	private String lusiadas =  "As armas e os barões assinalados,Que da ocidental praia Lusitana,Por mares nunca de antes navegados,Passaram ainda além da Taprobana,Em perigos e guerras ";
	//private Object cartaoNoName532 = 4712877;

	@AfterClass
	public void deletar_Todos_Motivos_Criados() {
		try {
			validador.droparMotivos();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void CT01_ListarMotivosTodos() {
		try {
			System.out.println("****Iniciando o teste: CT01_ListarMotivosTodos \n");
			LogReport.info("Iniciando o teste: CT01_ListarMotivosTodos");
			Response response = request.genericRequestGET2("Descricao", "", "", UrlUtils.token2,
					UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT02_ListarMotivosPorStatus() {
		try {
			System.out.println("****Iniciando o teste: CT02_ListarMotivosPorStatus \n");
			LogReport.info("Iniciando o teste: CT02_ListarMotivosPorStatus");
			Response response = request.genericRequestGET2("Descricao", "", "Status", UrlUtils.token2,
					UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT03_ListarMotivosPorConta() {
		try {
			System.out.println("****Iniciando o teste: CT02_ListarMotivosPorStatus \n");
			LogReport.info("Iniciando o teste: CT02_ListarMotivosPorStatus");
			Response response = request.genericRequestGET2("Descricao", "", "Conta", UrlUtils.token2,
					UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT04_ListarMotivosPorNumero() {
		try {
			System.out.println("****Iniciando o teste: CT04_ListarMotivosPorNumero \n");
			LogReport.info("Iniciando o teste: CT04_ListarMotivosPorNumero");
			Response response = request.genericRequestGET2("Descricao", "", "Numero", UrlUtils.token2,
					UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT05_ListarMotivosListaVazia() {
		try {
			System.out.println("****Iniciando o teste: CT05_ListarMotivosListaVazia \n");
			LogReport.info("Iniciando o teste: CT05_ListarMotivosListaVazia");
			Response response = request.genericRequestGET2("Descricao", "", "***teste***", UrlUtils.token2,
					UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT06_CadastrarMotivo() {
		try {
			System.out.println("****Iniciando o teste: CT06_CadastrarMotivo \n");
			LogReport.info("Iniciando o teste: CT06_CadastrarMotivo");
			dados = RequestBodyGenerator.motivoDescricao("Criacao Motivo Teste");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT07_CadastrarMotivoInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT06_CadastrarMotivo \n");
			LogReport.info("Iniciando o teste: CT06_CadastrarMotivo");
			dados = RequestBodyGenerator.motivoDescricao("-----"); 
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT08_CadastrarMotivoExistente() {
		try {
			System.out.println("****Iniciando o teste: CT08_CadastrarMotivoExistente \n");
			LogReport.info("Iniciando o teste: CT08_CadastrarMotivoExistente");
			dados = RequestBodyGenerator.motivoDescricao("Status da conta diferente de normal e liberado");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT09_CadastrarMotivoLimiteMax() {
		try {
			System.out.println("****Iniciando o teste: CT09_CadastrarMotivoLimiteMax \n");
			LogReport.info("Iniciando o teste: CT09_CadastrarMotivoLimiteMax");
			dados = RequestBodyGenerator.motivoDescricao(lusiadas);	
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT10_CadastrarMotivoLimiteMin() {
		try {
			System.out.println("****Iniciando o teste: CT10_CadastrarMotivoLimiteMin \n");
			LogReport.info("Iniciando o teste: CT10_CadastrarMotivoLimiteMin");
			dados = RequestBodyGenerator.motivoDescricao("A");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT11_CadastrarMotivoSemInformarDescricao() {
		try {
			System.out.println("****Iniciando o teste: CT11_CadastrarMotivoSemInformarDescricao \n");
			LogReport.info("Iniciando o teste: CT11_CadastrarMotivoSemInformarDescricao");
			dados = RequestBodyGenerator.motivoDescricao("");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT12_CadastrarMotivoCaracteresEspeciais() {
		try {
			System.out.println("****Iniciando o teste: CT12_CadastrarMotivoCaracteresEspeciais \n");
			LogReport.info("Iniciando o teste: CT12_CadastrarMotivoCaracteresEspeciais");
			dados = RequestBodyGenerator.motivoDescricao("!&¨@&!¨#!&#!*&@*!&*!&@*!&@\"");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT13_CadastrarMotivoCaracteresInvalidos() {
		try {
			System.out.println("****Iniciando o teste: CT13_CadastrarMotivoCaracteresInvalidos \n");
			LogReport.info("Iniciando o teste: CT13_CadastrarMotivoCaracteresInvalidos");
			dados = RequestBodyGenerator.motivoDescricao("(⌐■_■)(⌐■_■)(⌐■_■)");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT14_CadastrarMotivoInformandoID() {
		try {
			System.out.println("****Iniciando o teste: CT14_CadastrarMotivoInformandoID \n");
			LogReport.info("Iniciando o teste: CT14_CadastrarMotivoInformandoID");
			dados = RequestBodyGenerator.motivoDescricao(99);
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT15_CadastrarMotivoSemParametros() {
		try {
			System.out.println("****Iniciando o teste: CT15_CadastrarMotivoSemParametros \n");
			LogReport.info("Iniciando o teste: CT15_CadastrarMotivoSemParametros");
			dados = RequestBodyGenerator.motivoDescricao("");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT16_CadastrarMotivoDescricaoVazia() {
		try {
			System.out.println("****Iniciando o teste: CT16_CadastrarMotivoDescricaoVazia \n");
			LogReport.info("Iniciando o teste: CT16_CadastrarMotivoDescricaoVazia");
			dados = RequestBodyGenerator.motivoDescricao("");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT17_CadastrarMotivoDescricaoNULL() {
		try {
			System.out.println("****Iniciando o teste: CT17_CadastrarMotivoDescricaoNULL \n");
			LogReport.info("Iniciando o teste: CT17_CadastrarMotivoDescricaoNULL");
			dados = RequestBodyGenerator.motivoDescricao("null");
			Response response = request.genericRequestPOST(UrlUtils.token2,
					dados, UrlUtils.pierMotFraude, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT18_AlterarDescricaoMotivo() {
		try {
			System.out.println("****Iniciando o teste: CT18_AlterarDescricaoMotivo \n");
			LogReport.info("Iniciando o teste: CT18_AlterarDescricaoMotivo");
			dados = RequestBodyGenerator.motivoDescricao("Emissor não autoriza aprovação de celulares fora das listas e/ou do cadastro");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", 6, dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}

	@Test
	public void CT19_AlterarDescricaoMotivoInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT19_AlterarDescricaoMotivoInvalido \n");
			LogReport.info("Iniciando o teste: CT19_AlterarDescricaoMotivoInvalido");
			dados = RequestBodyGenerator.motivoDescricao(lusiadas);
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", 1, dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT20_AlterarDescricaoMotivoPorExistente() {
		try {
			System.out.println("****Iniciando o teste: CT20_AlterarDescricaoMotivoPorExistente \n");
			LogReport.info("Iniciando o teste: CT20_AlterarDescricaoMotivoPorExistente");
			dados = RequestBodyGenerator.motivoDescricao("Status da conta diferente de normal e liberado");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", 6, dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT21_AlterarDescricaoMotivoSemInformarDescricao() {
		try {
			System.out.println("****Iniciando o teste: CT21_AlterarDescricaoMotivoSemInformarDescricao \n");
			LogReport.info("Iniciando o teste: CT21_AlterarDescricaoMotivoSemInformarDescricao");
			dados = RequestBodyGenerator.motivoDescricao("");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", 66, dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT22_AlterarDescricaoMotivoInformandoAMesmaDescricao() {
		try {
			System.out.println("****Iniciando o teste: CT22_AlterarDescricaoMotivoInformandoAMesmaDescricao \n");
			LogReport.info("Iniciando o teste: CT22_AlterarDescricaoMotivoInformandoAMesmaDescricao");
			dados = RequestBodyGenerator.motivoDescricao("Emissor não autoriza aprovação de celulares fora das listas e/ou do cadastro");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", 6, dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT23_AlterarDescricaoMotivoInexistente() {
		try {
			System.out.println("****Iniciando o teste: CT23_AlterarDescricaoMotivoInexistente \n");
			LogReport.info("Iniciando o teste: CT23_AlterarDescricaoMotivoInexistente");
			dados = RequestBodyGenerator.motivoDescricao("Teste");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", 0, dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT24_AlterarDescricaoSemInformarID() {
		try {
			System.out.println("****Iniciando o teste: CT24_AlterarDescricaoSemInformarID \n");
			LogReport.info("Iniciando o teste: CT24_AlterarDescricaoSemInformarID");
			dados = RequestBodyGenerator.motivoDescricao("Teste");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", "", dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_METHOD_NOT_ALLOWED);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT25_AlterarDescricaoIDInexistente() {
		try {
			System.out.println("****Iniciando o teste: CT25_AlterarDescricaoIDInexistente \n");
			LogReport.info("Iniciando o teste: CT25_AlterarDescricaoIDInexistente");
			dados = RequestBodyGenerator.motivoDescricao("Teste");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", -1, dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT26_AlterarDescricaoIDInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT26_AlterarDescricaoIDInvalido \n");
			LogReport.info("Iniciando o teste: CT26_AlterarDescricaoIDInvalido");
			dados = RequestBodyGenerator.motivoDescricao("Teste");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", "id=66", dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT27_AlterarDescricaoIDNoBody() {
		try {
			System.out.println("****Iniciando o teste: CT27_AlterarDescricaoIDNoBody \n");
			LogReport.info("Iniciando o teste: CT27_AlterarDescricaoIDNoBody");
			dados = RequestBodyGenerator.motivoDescricao2("Teste",66);
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", "id=66", dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT28_AlterarDescricaoSemParametros() {
		try {
			System.out.println("****Iniciando o teste: CT28_AlterarDescricaoSemParametros \n");
			LogReport.info("Iniciando o teste: CT28_AlterarDescricaoSemParametros");
			dados = RequestBodyGenerator.motivoDescricao("");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", "", dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_METHOD_NOT_ALLOWED);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT29_AlterarDescricaoInformandoDescPath() {
		try {
			System.out.println("****Iniciando o teste: CT29_AlterarDescricaoInformandoDescPath \n");
			LogReport.info("Iniciando o teste: CT29_AlterarDescricaoInformandoDescPath");
			dados = RequestBodyGenerator.motivoDescricao("");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", "teste no path", dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT30_AlterarDescricaoInformandoDescPathIDPath() {
		try {
			System.out.println("****Iniciando o teste: CT30_AlterarDescricaoInformandoDescPathIDPath \n");
			LogReport.info("Iniciando o teste: CT30_AlterarDescricaoInformandoDescPathIDPath");
			dados = RequestBodyGenerator.motivoDescricao("");
			Response response = request.genericRequestPUT(UrlUtils.token2, "id", "teste", dados, 
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT31_ConsultarMotivoExistente() {
		try {
			System.out.println("****Iniciando o teste: CT31_ConsultarMotivoExistente \n");
			LogReport.info("Iniciando o teste: CT31_ConsultarMotivoExistente");
			Response response = request.genericRequestGET("id", "6", "", UrlUtils.token2,
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT32_ConsultarMotivoMaisRecente() {
		try {
			System.out.println("****Iniciando o teste: CT32_ConsultarMotivoMaisRecente \n");
			LogReport.info("Iniciando o teste: CT32_ConsultarMotivoMaisRecente");
			Response response = request.genericRequestGET("id", validador.BuscarMotivoRecente(), "", UrlUtils.token2,
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT33_ConsultarMotivoInexistente() {
		try {
			System.out.println("****Iniciando o teste: CT33_ConsultarMotivoInexistente \n");
			LogReport.info("Iniciando o teste: CT33_ConsultarMotivoInexistente");
			Response response = request.genericRequestGET("id", "999", "", UrlUtils.token2,
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT34_ConsultarMotivoIDInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT34_ConsultarMotivoIDInvalido \n");
			LogReport.info("Iniciando o teste: CT34_ConsultarMotivoIDInvalido");
			Response response = request.genericRequestGET("id", "motivo", "", UrlUtils.token2,
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
	
	@Test
	public void CT35_ConsultarMotivoSemInformarID() {
		try {
			System.out.println("****Iniciando o teste: CT35_ConsultarMotivoSemInformarID \n");
			LogReport.info("Iniciando o teste: CT35_ConsultarMotivoSemInformarID");
			Response response = request.genericRequestGET("id", "", "", UrlUtils.token2,
					UrlUtils.pierMotFraudePUT, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			Assert.fail();
		}

	}
}
