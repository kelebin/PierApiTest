package test;

import static org.junit.Assert.fail;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.EntityGenericUtil;
import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.response.Response;
import validacao.validador;

public class DadosReaisCartao extends BaseTest {
	private RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	//private Object ID_Pessoa = 4712877;

	
/*	@Test
	public void CT01_CadastrarFraude() {
		try {
			System.out.println("****Iniciando o teste: CT01_CadastrarFraude \n");
			Object idCartao = validador.BuscarCartao();
			LogReport.info("Iniciando o teste: CT01_CadastrarFraude");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestGET(idCartao, "", "88bmg232HML",
					UrlUtils.pierCartoesDadosReais, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
}*/
}
