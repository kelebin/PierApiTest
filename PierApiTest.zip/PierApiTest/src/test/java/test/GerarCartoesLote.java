package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.Test;
import org.mockito.Mockito;

import Utils.EntityGenericUtil;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import io.restassured.response.Response;
import validacao.validador;

public class GerarCartoesLote {

	public RequestGenerator request = new RequestGenerator();

	/*@Test
	public void GerarCartaoContaSemProduto() {
		try {
			Map dados = RequestBodyGenerator.gerarBodyCartao(4,2);
			 Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),1,dados
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void GerarCartao() {
		try {
			Map dados = RequestBodyGenerator.gerarBodyCartao(4,2);
			 Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),2,dados
					,UrlUtils.urlCartoes,204);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void GerarCartaoIDCONTAOutroProduto() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)1234,
					RequestBodyGenerator.gerarBodyCartao((long)123,(long)2)
					,UrlUtils.urlCartoes,204);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoContaInexistente() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)99999999,
					RequestBodyGenerator.gerarBodyCartao((long)123,(long)1)
					,UrlUtils.urlCartoes,404);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoContaInvalida() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)-1234,
					RequestBodyGenerator.gerarBodyCartao((long)123,(long)1)
					,UrlUtils.urlCartoes,404);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoNaoINformarIdConta() {
		try {
			// Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(),
					RequestBodyGenerator.gerarBodyCartao((long)12345,(long)12345)
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoIdPessoaDiferente() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)1,
					RequestBodyGenerator.gerarBodyCartao((long)12,(long)1)
					,UrlUtils.urlCartoes,204);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoIdPessoaInexistente() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)1234,
					RequestBodyGenerator.gerarBodyCartao((long)99999999,(long)12345)
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoIdPessoaInvalido() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)1234,
					RequestBodyGenerator.gerarBodyCartao("12345",(long)12345)
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoSemInformarIdPessoa() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)1234,
					RequestBodyGenerator.gerarBodyCartao(Mockito.anyString(),(long)12345)
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoLoteDiferente() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)1,
					RequestBodyGenerator.gerarBodyCartao((long)123,Mockito.anyLong())
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoLoteInexistente() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)1,
					RequestBodyGenerator.gerarBodyCartao((long)123,(long)1234567)
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoLoteInvalido() {
		try {
			// Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),(long)1234,
					RequestBodyGenerator.gerarBodyCartao((long)12345,"1234")
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}
	
	@Test
	public void GerarCartaoSemInformarLote() {
		try {
			 Map dados = RequestBodyGenerator.gerarBodyCartao(12345,null);
			 Response response =
			request.genericRequestPOST2(EntityGenericUtil.getToken(),1234,dados
					,UrlUtils.urlCartoes,400);
		} catch (Exception e) {
			System.out.println("Fail");
			fail();
		}
	}*/
	
}
