package test;

import org.junit.Test;

import Utils.EntityGenericUtil;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import validacao.validador;

public class ListarLotes {
	public RequestGenerator request = new RequestGenerator();

	public validador validador = new validador();

/*	@Test
	public void ListarTodosLotes() {
		try {
			// Response response =
			request.genericRequestGET("", "",
					EntityGenericUtil.getToken(), UrlUtils.pierLote, 200);
		} catch (Exception e) {
		}
	}

	@Test
	public void ListarLotesSemTerLotes() {
		try {
			// Response response =
			request.genericRequestGET("teste", "teste",
					EntityGenericUtil.getToken(), UrlUtils.pierLote, 400);
		} catch (Exception e) {
		}
	}
	
	@Test
	public void ListarLotesComParametros() {
		try {
			// Response response =
			request.genericRequestGET("teste", "teste",
					EntityGenericUtil.getToken(),UrlUtils.pierLote, 400);
		} catch (Exception e) {
		}
	}
*/

}
