package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.EntityGenericUtil;
import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.response.Response;
import validacao.validador;

public class MiddlewareAtribuir extends BaseTest{

	private RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	private Object cartaoNoName532 = 4712877;

	/*@Test
	public void CT00_AtribuirCartaoProduto532() {
		try {
			System.out.println("****Iniciando o teste: CT01_AtribuirCartaoProduto532 \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(11015247, 4317470, 1137451, 532);
			LogReport.info("Iniciando o teste: CT01_AtribuirCartaoProduto532");
			LogReport.json(gson.toJson(dados));
			Response response  = request.RequestGET("sequencialCartao,desc", 1, 4712877, 
					UrlUtils.token2, UrlUtils.pierCartoes, HttpStatus.SC_OK);
			Response response2 = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_OK);
			Response response3 = request.RequestGET("sequencialCartao,desc", 1, 1234, 
					UrlUtils.token2, UrlUtils.pierCartoes, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}*/
	
	
	@Test
	public void CT01_AtribuirCartaoProduto532() {
		try {
			System.out.println("****Iniciando o teste: CT01_AtribuirCartaoProduto532 \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(11033570, 4169280, 4390101, 533);
			LogReport.info("Iniciando o teste: CT01_AtribuirCartaoProduto532");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	
	@Test
	public void CT01Bonus_AtribuirCartaoProduto532FuncaoAtivaDebito() {
		try {
			System.out.println("****Iniciando o teste: CT01Bonus_AtribuirCartaoProduto532FuncaoAtivaDebito \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 4402747, 4674227, 53);
			LogReport.info("Iniciando o teste: CT01_AtribuirCartaoProduto532");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getMap("$"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT02_AtribuirCartaoContaJaTemCartaoAtribuido() {
		try {
			System.out.println("****Iniciando o teste: CT2_AtribuirCartaoContaJaTemCartaoAtribuido \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 4079373, 3902224, 532);
			LogReport.info("Iniciando o teste: CT2_AtribuirCartaoContaJaTemCartaoAtribuido");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT03_AtribuirCartaoProdutoNaoPermite() {
		try {
			System.out.println("****Iniciando o teste: CT2_AtribuirCartaoProdutoNaoPermite \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 1, 1, 530);
			LogReport.info("Iniciando o teste: CT2_AtribuirCartaoProdutoNaoPermite");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT04_AtribuirCataoProdutoNaoExiste() {
		try {
			System.out.println("****Iniciando o teste: CT4_AtribuirCataoProdutoNaoExiste \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 4525988, 2675140, 888);
			LogReport.info("Iniciando o teste: CT4_AtribuirCataoProdutoNaoExiste");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT05_AtribuirCartaoProdutoInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT5_AtribuirCartaoProdutoInvalido \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 4525988, 2675140, -1);
			LogReport.info("Iniciando o teste: CT5_AtribuirCartaoProdutoInvalido");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT06_AtribuidCartaoProdutoNULL() {
		try {
			System.out.println("****Iniciando o teste: CT6_AtribuidCartaoProdutoNULL \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 4525988, 2675140, null);
			LogReport.info("Iniciando o teste: CT6_AtribuidCartaoProdutoNULL");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT07_AtribuirCartaoIDpessoaIncorreto() {
		try {
			System.out.println("****Iniciando o teste: CT7_AtribuirCartaoIDpessoaIncorreto \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 579040, 579040, 532);
			LogReport.info("Iniciando o teste: CT7_AtribuirCartaoIDpessoaIncorreto");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT08_AtribuirCartaoIDpessoaInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT8_AtribuirCartaoIDpessoaInvalido \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(11015246, 4525988, "abc", 532);
			LogReport.info("Iniciando o teste: CT8_AtribuirCartaoIDpessoaInvalido");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT09_AtribuirCartaoIDpessoaNULL() {
		try {
			System.out.println("****Iniciando o teste: CT9_AtribuirCartaoIDpessoaNULL \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(11015246, 4525988, null, 532);
			LogReport.info("Iniciando o teste: CT9_AtribuirCartaoIDpessoaNULL");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT10_AtribuirCartaoIDpessoaInvalidoNegativo() {
		try {
			System.out.println("****Iniciando o teste: CT10_AtribuirCartaoIDpessoaInvalidoNegativo \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 4525988, -1, 532);
			LogReport.info("Iniciando o teste: CT10_AtribuirCartaoIDpessoaInvalidoNegativo");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT11_AtribuirCartaoIDpessoaInexistente() {
		try {
			System.out.println("****Iniciando o teste: CT11_AtribuirCartaoIDpessoaInexistente \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 4525988, 999999999, 532);
			LogReport.info("Iniciando o teste: CT11_AtribuirCartaoIDpessoaInexistente");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT12_AtribuirCartaoIDContaInexistente() {
		try {
			System.out.println("****Iniciando o teste: CT12_AtribuirCartaoIDContaInexistente \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(11015009, 94525988, 992675140, 532);
			LogReport.info("Iniciando o teste: CT12_AtribuirCartaoIDContaInexistente");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT13_AtribuirCartaoIDContaInvalido() {
		try {
			System.out.println("****Iniciando o teste: CT13_AtribuirCartaoIDContaInvalido \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(11015246, "idconta", 2675140, 532);
			LogReport.info("Iniciando o teste: CT13_AtribuirCartaoIDContaInvalido");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT14_AtribuirCartaoIDContaNull() {
		try {
			System.out.println("****Iniciando o teste: CT14_AtribuirCartaoIDContaNull \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(11015246, null, 2675140, 532);
			LogReport.info("Iniciando o teste: CT14_AtribuirCartaoIDContaNull");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	
	@Test
	public void CT15_AtribuirCartaoIDContaFuncaoAtivaCredito() {
		try {
			System.out.println("****Iniciando o teste: CT15_AtribuirCartaoIDContaFuncaoAtivaCredito \n");
			Object cartao = validador.setupAtribuir(cartaoNoName532);
			dados = RequestBodyGenerator.middlewareAtribuicao(cartao, 3686551, 2606207, 532);
			LogReport.info("Iniciando o teste: CT15_AtribuirCartaoIDContaFuncaoAtivaCredito");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	
	@Test
	public void CT16_AtribuirCartaoIDCartaoNaoENoName() {
		try {
			System.out.println("****Iniciando o teste: CT16_AtribuirCartaoIDCartaoNaoENoName \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(1, 4525988, 2675140, 532);
			LogReport.info("Iniciando o teste: CT16_AtribuirCartaoIDCartaoNaoENoName");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	
	@Test
	public void CT17_AtribuirCartaoIDCartaoinexistente() {
		try {
			System.out.println("****Iniciando o teste: CT17_AtribuirCartaoIDCartaoinexistente \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(921015246, 4525988, 2675140, 532);
			LogReport.info("Iniciando o teste: CT17_AtribuirCartaoIDCartaoinexistente");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT18_AtribuirCartaoIDCartaoinvalido() {
		try {
			System.out.println("****Iniciando o teste: CT18_AtribuirCartaoIDCartaoinvalido \n");
			dados = RequestBodyGenerator.middlewareAtribuicao("cartao", 4525988, 2675140, 532);
			LogReport.info("Iniciando o teste: CT18_AtribuirCartaoIDCartaoinvalido");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT19_AtribuirCartaoIDCartaoJaAtribuido() {
		try {
			System.out.println("****Iniciando o teste: CT19_AtribuirCartaoIDCartaoJaAtribuido \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(11015051, 4525988, 2675140, 532);
			LogReport.info("Iniciando o teste: CT19_AtribuirCartaoIDCartaoJaAtribuido");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
	
	@Test
	public void CT20_AtribuirCartaoIDCartaoNull() {
		try {
			System.out.println("****Iniciando o teste: CT20_AtribuirCartaoIDCartaoNull \n");
			dados = RequestBodyGenerator.middlewareAtribuicao(null, 4525988, 2675140, 532);
			LogReport.info("Iniciando o teste: CT20_AtribuirCartaoIDCartaoNull");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", dados,
					UrlUtils.HeimdallHMLQAAtribuir, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().get("message"));
			// assertTrue(validador.validarBodyRequest(response, dados));
			// validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}

	}
}

