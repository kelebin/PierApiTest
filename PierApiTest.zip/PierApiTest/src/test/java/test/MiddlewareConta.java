package test;

import static org.junit.Assert.fail;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.EntityGenericUtil;
import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.response.Response;

public class MiddlewareConta extends BaseTest {

	private RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	
	
	
	@Test
	public void criarContaBmgMais() {
		try {
			System.out.println("****Iniciando o teste: criarConta \n");
			dados = RequestBodyGenerator.pessoaPersist(1,  "DEBITOCREDITO",  1);
			LogReport.info("Iniciando o teste: criarContaBmgMais");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void criarContaBmgMaisCorinthiansParceriaSemParceria() {
		try {
			System.out.println("****Iniciando o teste: criarContaBmgMaisCorinthiansParceriaSemParceria \n");
			dados = RequestBodyGenerator.pessoaPersist(535,  "CREDITO",  1);
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void criarContaBmgMaisParceria() {
		try {
			System.out.println("****Iniciando o teste: criarContaBmgMaisParceria \n");
			dados = RequestBodyGenerator.pessoaPersist(1,  "CREDITO",  22);
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void criarContaBmgMaisCorinthiansParceria() {
		try {
			System.out.println("****Iniciando o teste: criarContaBmgMaisParceria \n");
			dados = RequestBodyGenerator.pessoaPersist(535,  "CREDITO",  22);
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void criarContaBmgMaisCorinthiansOutroServico() {
		try {
			System.out.println("****Iniciando o teste: criarContaBmgMaisCorinthiansOutroServico \n");
			dados = RequestBodyGenerator.pessoaPersist(535,  "CREDITO",  21);
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void criarContaBmgMaisCorinthiansSemServico() {
		try {
			System.out.println("****Iniciando o teste: criarContaBmgMaisCorinthiansSemServico \n");
			dados = RequestBodyGenerator.pessoaPersist(535,  "CREDITO",  null);
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void criarContaBmgMaisCorinthiansServicoInexistente() {
		try {
			System.out.println("****Iniciando o teste: criarContaBmgMaisCorinthiansServicoInexistente \n");
			dados = RequestBodyGenerator.pessoaPersist(535,  "CREDITO",  999);
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void criarContaBmgMaisCorinthiansServicoInvalido() {
		try {
			System.out.println("****Iniciando o teste: criarContaBmgMaisCorinthiansServicoInvalido \n");
			dados = RequestBodyGenerator.pessoaPersist(535,  "CREDITO",  "parceria");
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void criarContaBmgMaisCorinthiansServicoInvalidoNegativo() {
		try {
			System.out.println("****Iniciando o teste: criarContaBmgMaisCorinthiansServicoInvalidoNegativo \n");
			dados = RequestBodyGenerator.pessoaPersist(535,  "CREDITO",  -1);
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
}
