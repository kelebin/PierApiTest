package test;

import static org.junit.Assert.fail;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.EntityGenericUtil;
import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.response.Response;

public class MiddlewareContaNoName extends BaseTest {
	private RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	
	
	@Test
	public void CT1_Cadastrar_nova_conta_tipo_DEBITOCREDITO() {
		try {
			System.out.println("****Iniciando o teste: Cadastrar_nova_conta_tipoDEBITOCREDITO \n");
			dados = RequestBodyGenerator.pessoaPersist(1,  "DEBITOCREDITO",  1);
			LogReport.info("Iniciando o teste: Cadastrar_nova_conta_tipoDEBITOCREDITO");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	@Test
	public void CT2_Cadastrar_nova_conta_tipo_CREDITO() {
		try {
			System.out.println("****Iniciando o teste: Cadastrar_nova_conta_tipo_CREDITO \n");
			dados = RequestBodyGenerator.pessoaPersist(1,  "CREDITO",  1);
			LogReport.info("Iniciando o teste: Cadastrar_nova_conta_tipo_CREDITO");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	@Test
	public void CT3_Cadastrar_nova_conta_tipo_DEBITO() {
		try {
			System.out.println("****Iniciando o teste: Cadastrar_nova_conta_tipo_DEBITO \n");
			dados = RequestBodyGenerator.pessoaPersist(1,  "DEBITO",  1);
			LogReport.info("Iniciando o teste: Cadastrar_nova_conta_tipo_DEBITO");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	@Test
	public void CT4_Cadastrar_nova_conta_sem_informar_funcao_ativa() {
		try {
			System.out.println("****Iniciando o teste: Cadastrar_nova_conta_sem_informar_funcao_ativa \n");
			dados = RequestBodyGenerator.pessoaPersist(1,  "",  1);
			LogReport.info("Iniciando o teste: Cadastrar_nova_conta_sem_informar_funcao_ativa");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	@Test
	public void CT5_Cadastrar_nova_conta_informando_funcao_ativa_null() {
		try {
			System.out.println("****Iniciando o teste: Cadastrar_nova_conta_informando_funcao_ativa_null \n");
			dados = RequestBodyGenerator.pessoaPersist(1,  null,  1);
			LogReport.info("Iniciando o teste: Cadastrar_nova_conta_informando_funcao_ativa_null");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	@Test
	public void CT6_Cadastrar_nova_conta_informando_funcao_ativa_invalida() {
		try {
			System.out.println("****Iniciando o teste: Cadastrar_nova_conta_informando_funcao_ativa_invalida \n");
			dados = RequestBodyGenerator.pessoaPersist(1,  "123",  1);
			LogReport.info("Iniciando o teste: CT6_Cadastrar_nova_conta_informando_funcao_ativa_invalida");
			LogReport.json(gson.toJson(dados));
			Response response = request.genericRequestPOST("", EntityGenericUtil.formatadorJson(gson.toJson(dados)), 
			UrlUtils.HeimdallHMLQA,	HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.info(response.jsonPath().getString("error.message"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
}
