package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.Test;

import Utils.EntityGenericUtil;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import io.restassured.response.Response;
import validacao.validador;

public class MiddlewareDadosBancariosConta {
public RequestGenerator request = new RequestGenerator();
	
	@Test
	public void dadosBancariosConta() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosConta \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(1, 1, "123", 0, 1);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	201);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void dadosBancariosContaBancoInexistente() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaBancoInexistente \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(1, 1, "123", 99, 1);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	404);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void dadosBancariosContaNaoInformarDados() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaNaoInformarDados \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(null, null, null, null, null);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	400);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void dadosBancariosContaInterna() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaInterna \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(1, 1, "123", 0, 2);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	400);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void dadosBancariosContaInterna2() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaInterna2 \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(99, 1, "123", 0, 3);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	400);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
	}
	
	@Test
	public void dadosBancariosContaInterna3() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaInterna3 \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(100, 1, "123", 0, 99);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	400);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
}
	
	@Test
	public void dadosBancariosContaInterna4() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaInterna4 \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(1, 1, "123", 0, 0);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	400);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
}
	@Test
	public void dadosBancariosContaTipoContaInvalido() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaTipoContaInvalido \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(1, 0, 123, 0, "abc");
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	400);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
}
	@Test
	public void dadosBancariosContaTipoContaNegativo() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaTipoContaNegativo \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(99, 0, 123, 0, "-9999");
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	400);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
}
	@Test
	public void dadosBancariosContasemDadOBancario() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContasemDadOBancario \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(99, 0, "123", 0, 1);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	201);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
}
	@Test
	public void dadosBancariosContasemDadOBancarioInvalido() {
		try {
			System.out.println("****Iniciando o teste: dadosBancariosContaTipoContaNegativo \n");
			Map dados = RequestBodyGenerator.dadosBancariosConta(99, 0, 123, 0, "-1");
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.HeimdallHML,	400);
			assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste!");
			fail();
		}
}
}
