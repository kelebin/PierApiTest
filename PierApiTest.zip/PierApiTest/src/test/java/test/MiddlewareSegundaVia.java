package test;

import static org.junit.Assert.fail;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.response.Response;

public class MiddlewareSegundaVia extends BaseTest{
	private RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	
	
	
	@Test
	public void ct_00_gerarSegundaViaBMG() {
		try {
			System.out.println("****Iniciando o teste: ct_00_gerarSegundaViaBMG \n");
			Map dados = RequestBodyGenerator.segundaVia(9728866);
			LogReport.info("Iniciando o teste: ct_00_gerarSegundaViaBMG");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_01_gerarSegundaViaPagSeguro() {
		try {
			System.out.println("****Iniciando o teste: ct_01_gerarSegundaViaPagSeguro \n");
			Map dados = RequestBodyGenerator.segundaVia(1952403);
			LogReport.info("Iniciando o teste: ct_01_gerarSegundaViaPagSeguro");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_NOT_FOUND);
			if (response.getStatusCode() != HttpStatus.SC_NOT_FOUND) {
				LogReport.info("HTTP STATUS: " + response.getStatusCode());
			}
			else {
				LogReport.info("HTTP STATUS: " + response.getStatusCode());
				LogReport.info(response.jsonPath().getString("error.message"));
			}
			//LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_02_gerarSegundaViaBMGProdutoParametrizado() {
		try {
			System.out.println("****Iniciando o teste: ct_02_gerarSegundaViaBMGProdutoParametrizado \n");
			Map dados = RequestBodyGenerator.segundaVia(9535605);
			LogReport.info("Iniciando o teste: ct_02_gerarSegundaViaBMGProdutoParametrizado");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_03_gerarSegundaViaBMGProdutoNaoParametrizado() {
		try {
			System.out.println("****Iniciando o teste: ct_03_gerarSegundaViaBMGProdutoNaoParametrizado \n");
			Map dados = RequestBodyGenerator.segundaVia(8311384);
			LogReport.info("Iniciando o teste: ct_03_gerarSegundaViaBMGProdutoNaoParametrizado");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_04_gerarSegundaViaBMGLimiteSuperior() {
		try {
			System.out.println("****Iniciando o teste: ct_04_gerarSegundaViaBMGLimiteSuperior \n");
			Map dados = RequestBodyGenerator.segundaVia(11120995);
			LogReport.info("Iniciando o teste: ct_04_gerarSegundaViaBMGLimiteSuperior");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_05_gerarSegundaViaBMGLimiteMinimo() {
		try {
			System.out.println("****Iniciando o teste: ct_05_gerarSegundaViaBMGLimiteMinimo \n");
			Map dados = RequestBodyGenerator.segundaVia(9787844);
			LogReport.info("Iniciando o teste: ct_05_gerarSegundaViaBMGLimiteMinimo");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_06_gerarSegundaViaBMGLimiteInferior() {
		try {
			System.out.println("****Iniciando o teste: ct_06_gerarSegundaViaBMGLimiteInferior \n");
			Map dados = RequestBodyGenerator.segundaVia(11027306);
			LogReport.info("Iniciando o teste: ct_06_gerarSegundaViaBMGLimiteInferior");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_07_gerarSegundaViaBMGDataAlteracaoSuperior() {
		try {
			System.out.println("****Iniciando o teste: ct_07_gerarSegundaViaBMGDataAlteracaoSuperior \n");
			Map dados = RequestBodyGenerator.segundaVia(1234);
			LogReport.info("Iniciando o teste: ct_07_gerarSegundaViaBMGDataAlteracaoSuperior");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_08_gerarSegundaViaBMGDataAlteracaoMinima() {
		try {
			System.out.println("****Iniciando o teste: ct_08_gerarSegundaViaBMGDataAlteracaoMinima \n");
			Map dados = RequestBodyGenerator.segundaVia(1234);
			LogReport.info("Iniciando o teste: ct_08_gerarSegundaViaBMGDataAlteracaoMinima");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_09_gerarSegundaViaBMGDataAlteracaoInferior() {
		try {
			System.out.println("****Iniciando o teste: ct_09_gerarSegundaViaBMGDataAlteracaoInferior \n");
			Map dados = RequestBodyGenerator.segundaVia(1234);
			LogReport.info("Iniciando o teste: ct_09_gerarSegundaViaBMGDataAlteracaoInferior");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_10_gerarSegundaViaBMGCartaoBloqueado() {
		try {
			System.out.println("****Iniciando o teste: ct_10_gerarSegundaViaBMGCartaoBloqueado \n");
			Map dados = RequestBodyGenerator.segundaVia(8751);
			LogReport.info("Iniciando o teste: ct_10_gerarSegundaViaBMGCartaoBloqueado");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_11_gerarSegundaViaBMGContaBloqueada() {
		try {
			System.out.println("****Iniciando o teste: ct_11_gerarSegundaViaBMGContaBloqueada \n");
			Map dados = RequestBodyGenerator.segundaVia(10719956);
			LogReport.info("Iniciando o teste: ct_11_gerarSegundaViaBMGContaBloqueada");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_12_gerarSegundaViaBMGCartaoInexistente() {
		try {
			System.out.println("****Iniciando o teste: ct_12_gerarSegundaViaBMGCartaoInexistente \n");
			Map dados = RequestBodyGenerator.segundaVia(99999999);
			LogReport.info("Iniciando o teste: ct_12_gerarSegundaViaBMGCartaoInexistente");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_NOT_FOUND);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_13_gerarSegundaViaBMGCartaoNoName() {
		try {
			System.out.println("****Iniciando o teste: ct_13_gerarSegundaViaBMGCartaoNoName \n");
			Map dados = RequestBodyGenerator.segundaVia(10921890);
			LogReport.info("Iniciando o teste: ct_13_gerarSegundaViaBMGCartaoNoName");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_14_gerarSegundaViaBMGCartaoInvalido() {
		try {
			System.out.println("****Iniciando o teste: ct_14_gerarSegundaViaBMGCartaoInvalido \n");
			Map dados = RequestBodyGenerator.segundaVia("12asd");
			LogReport.info("Iniciando o teste: ct_14_gerarSegundaViaBMGCartaoInvalido");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_15_gerarSegundaViaBMGCartaoNULL() {
		try {
			System.out.println("****Iniciando o teste: ct_15_gerarSegundaViaBMGCartaoNULL \n");
			Map dados = RequestBodyGenerator.segundaVia(null);
			LogReport.info("Iniciando o teste: ct_15_gerarSegundaViaBMGCartaoNULL");
			LogReport.info(dados);
			Response response = request.genericRequestPOST("", dados, 
			UrlUtils.MiddlewareSegundaVia, HttpStatus.SC_BAD_REQUEST);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
}
