package test;

import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.Test;

import Utils.EntityGenericUtil;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import io.restassured.response.Response;

public class MiddlewareTrocaFuncaoAtiva {

	public RequestGenerator request = new RequestGenerator();

	@Test
	public void trocarFuncaoAtiva() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long) 4591949, "CREDITO", (long) 10648697);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 200);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	
	@Test
	public void trocarFuncaoAtivaCartaoDeOutroPortador() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long) 4360789, "DEBITOCREDITO", (long) 1);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 400);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void trocarFuncaoAtivaMesmaFuncao() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long) 4, "DEBITO", (long) 1);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 400);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void trocarFuncaoAtivaContaInexistente() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long)99999999, "DEBITOCREDITO", (long) 10313995);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 400);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void trocarFuncaoAtivaContaInvalida() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long)-999, "DEBITOCREDITO", (long) 10313995);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 400);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void trocarFuncaoAtivaInvalida() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long)4345976, 99, (long) 10313995);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 400);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void trocarFuncaoAtivaInvalidaNULL() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long)4345976, null, (long) 10313995);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 400);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void trocarFuncaoAtivaInvalidaNaoInformar() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long)-999,"", (long) 10313995);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 400);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void trocarFuncaoAtivaIdCartaoINvalido() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long)4345976,"DEBITOCREDITO", (long) 00000);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 404);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	@Test
	public void trocarFuncaoAtivaIdCartaoINvalido2() {
		try {
			Map dados = RequestBodyGenerator.dadosMiddleware((long)4345976,"DEBITOCREDITO", (long) -1);
			 Response response =
			request.genericRequestPOST(EntityGenericUtil.getToken(), dados, UrlUtils.urlFuncaoAtiva, 404);
		} catch (Exception e) {
		System.out.println("Fail");
		fail();
		}
	}
	
	
}
