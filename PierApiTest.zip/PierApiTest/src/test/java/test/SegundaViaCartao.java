package test;

import static org.junit.Assert.fail;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import Utils.EntityGenericUtil;
import Utils.LogReport;
import Utils.RequestBodyGenerator;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import core.BaseTest;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class SegundaViaCartao extends BaseTest{
	private RequestGenerator request = new RequestGenerator();
	private Gson gson = new Gson();
	private Map dados = new LinkedHashMap();
	
	

	/*
	@Test
	public void ct_001_gerarSegundaViaMult() {
		try {
			System.out.println("****Iniciando o teste: gerarSegundaVia \n");
			int idCartao = 10224797;
			LogReport.info("Iniciando o teste: gerarSegundaVia");
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaViaMultiplo, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	*/
	
	
/*	@Test
	public void ct_00_gerarSegundaViaBMG() {
		try {
			System.out.println("****Iniciando o teste: ct_00_gerarSegundaViaBMG \n");
			int idCartao = 10224797;
			LogReport.info("Iniciando o teste: ct_00_gerarSegundaViaBMG");
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			LogReport.json(response.jsonPath().getMap("$"));
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	

	@Test
	public void ct_01_gerarSegundaViaPagSeguro() {
		try {
			System.out.println("****Iniciando o teste: ct_01_gerarSegundaViaPagSeguro \n");
			int idCartao = 10224797;
			LogReport.info("Iniciando o teste: ct_01_gerarSegundaViaPagSeguro");
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_02_gerarSegundaViaProdutoPermite() {
		try {
			System.out.println("****Iniciando o teste: ct_02_gerarSegundaViaProdutoPermite \n");
			LogReport.info("Iniciando o teste: ct_02_gerarSegundaViaProdutoPermite");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	

	@Test
	public void ct_03_gerarSegundaViaProdutoNaoPermite() {
		try {
			System.out.println("****Iniciando o teste: ct_03_gerarSegundaViaProdutoNaoPermite \n");
			LogReport.info("Iniciando o teste: ct_03_gerarSegundaViaProdutoNaoPermite");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_04_gerarSegundaViaLimiteSuperior() {
		try {
			System.out.println("****Iniciando o teste: ct_04_gerarSegundaViaLimiteSuperior \n");
			LogReport.info("Iniciando o teste: ct_04_gerarSegundaViaLimiteSuperior");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_05_gerarSegundaViaLimiteMinimo() {
		try {
			System.out.println("****Iniciando o teste: ct_05_gerarSegundaViaLimiteMinimo \n");
			LogReport.info("Iniciando o teste: ct_05_gerarSegundaViaLimiteMinimo");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_06_gerarSegundaViaLimiteInferiorAoMinimo() {
		try {
			System.out.println("****Iniciando o teste: ct_06_gerarSegundaViaLimiteInferiorAoMinimo \n");
			LogReport.info("Iniciando o teste: ct_06_gerarSegundaViaLimiteInferiorAoMinimo");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_07_gerarSegundaViaAlteracaoEnderecoMenorQueMinimo() {
		try {
			System.out.println("****Iniciando o teste: ct_07_gerarSegundaViaAlteracaoEnderecoMenorQueMinimo \n");
			LogReport.info("Iniciando o teste: ct_07_gerarSegundaViaAlteracaoEnderecoMenorQueMinimo");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_08_gerarSegundaViaAlteracaoEnderecoTempoMinimo() {
		try {
			System.out.println("****Iniciando o teste: ct_08_gerarSegundaViaAlteracaoEnderecoTempoMinimo \n");
			LogReport.info("Iniciando o teste: ct_08_gerarSegundaViaAlteracaoEnderecoTempoMinimo");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_09_gerarSegundaViaAlteracaoEnderecoSuperiorTempoMinimo() {
		try {
			System.out.println("****Iniciando o teste: ct_09_gerarSegundaViaAlteracaoEnderecoSuperiorTempoMinimo \n");
			LogReport.info("Iniciando o teste: ct_09_gerarSegundaViaAlteracaoEnderecoSuperiorTempoMinimo");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}

	@Test
	public void ct_10_gerarSegundaViaContaBloqueada() {
		try {
			System.out.println("****Iniciando o teste: ct_10_gerarSegundaViaContaBloqueada \n");
			LogReport.info("Iniciando o teste: ct_10_gerarSegundaViaContaBloqueada");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_11_gerarSegundaViaContaInexistente() {
		try {
			System.out.println("****Iniciando o teste: ct_11_gerarSegundaViaContaInexistente \n");
			LogReport.info("Iniciando o teste: ct_11_gerarSegundaViaContaInexistente");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}
	
	@Test
	public void ct_12_gerarSegundaViaContaNoName() {
		try {
			System.out.println("****Iniciando o teste: ct_12_gerarSegundaViaContaNoName \n");
			LogReport.info("Iniciando o teste: ct_12_gerarSegundaViaContaNoName");
			int idCartao = 10224797;
			LogReport.info("ID do cartao: "+idCartao);
			Response response = request.genericRequestPOST2(UrlUtils.token2,idCartao , "", 
			UrlUtils.PathSegundaVia, HttpStatus.SC_OK);
			LogReport.info("HTTP STATUS: " + response.getStatusCode());
			//assertTrue(validador.validarBodyRequest(response, dados));
			//validador.validarDadosBanco(response);
		} catch (Exception e) {
			System.out.println("Erro no teste! \n" + e);
			fail();
		}
	}*/
}
