package test;

import org.junit.Test;

import Utils.EntityGenericUtil;
import Utils.RequestGenerator;
import Utils.UrlUtils;
import io.restassured.response.Response;
import validacao.validador;

public class TiposLotesServico {

	public RequestGenerator request = new RequestGenerator();

	public validador validador = new validador();

/*	@Test
	public void ListarTiposLotes() {
		try {
			// Response response =
			request.genericRequestGET("", "", EntityGenericUtil.getToken(), UrlUtils.getMetodoPierLote(), 200);
		} catch (Exception e) {
		}
	}

	@Test
	public void ListarTiposLotesComPartametros() {
		try {
			// Response response =
			request.genericRequestGET("teste", "teste", EntityGenericUtil.getToken(), UrlUtils.getMetodoPierLote(),
					400);
		} catch (Exception e) {
		}
	}
*/
}
