package validacao;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import DataBase.Conexao;
import DataBase.Queries;
import io.restassured.response.Response;

public class validador extends Conexao {

	public static boolean validarBodyRequest(Response response, Map mapa) {
		Map<String, Object> jsonResponse = response.jsonPath().getMap("$");

		for (Object atributo : mapa.keySet()) {

			if (jsonResponse.containsKey(atributo)) {
				boolean resultado = jsonResponse.get(atributo).equals(mapa.get(atributo));

				if (!resultado) {
					return resultado;
				}
			}
		}

		return true;

	

	}

	public static void validarDadosBanco(Response response) throws SQLException, ClassNotFoundException {
		Map<String, String> jsonResponse = response.jsonPath().getMap("$");
		Object idLote = jsonResponse.get("idLote");
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url, user, passwd);
		Statement stmt = con.createStatement();
		sql = "SELECT * FROM Lotes WHERE id_Lote = " + idLote + "";
		ResultSet res = stmt.executeQuery(sql);
		Object resFinal = null;

		while (res.next()) {
			resFinal = res.getObject("id_Lote");
		}

		assertEquals(idLote, resFinal);

		con.close();
	}
	
	
	public static Object setupAtribuir(Object idContaNoName) throws SQLException, ClassNotFoundException {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url, user, passwd);
		Statement stmt = con.createStatement();
		// buscar o cartao noname
		sql = "select top 1 id_cartao from cartoes where id_conta = " + idContaNoName
				+ " and estagio = 4 order by newid()";
		ResultSet res = stmt.executeQuery(sql);

		Object resFinal = null;
		while (res.next()) {
			resFinal = res.getObject("id_cartao");
		}

		// inserir o cartao na tabela execucoeslotes
		sql = "insert into execucoeslotes\r\n" + "values (1022," + resFinal + ", '',getdate())";

		stmt.executeUpdate(sql);

		// buscar conta para receber o cartao
		/*
		 * sql =
		 * "select top 1 * from contas where funcaoativa = 0 and status = 0 order by newid()"
		 * ; ResultSet res2 = stmt.executeQuery(sql);
		 */

		con.close();
		return resFinal;
	}
	
	public static Object BuscarPessoa() throws SQLException, ClassNotFoundException {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url, user, passwd);
		Statement stmt = con.createStatement();
		// buscar pessoa
				
				  sql =
				  "select top 1 id_pessoa from contas order by newid()"
				  ; ResultSet res2 = stmt.executeQuery(sql);
				 
		ResultSet res = stmt.executeQuery(sql);

		Object resFinal = null;
		while (res.next()) {
			resFinal = res.getObject("id_pessoa");
		}

		con.close();
		return resFinal;
	}
	
	
	public static Object BuscarCartao() throws SQLException, ClassNotFoundException {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url, user, passwd);
		Statement stmt = con.createStatement();
		// buscar pessoa
				
				  sql =
				  "select top 1 c.id_cartao from Contas co inner join Cartoes c on c.id_conta = co.id_conta where co.FuncaoAtiva = 0 order by newid()"
				  ; ResultSet res2 = stmt.executeQuery(sql);
				 
		ResultSet res = stmt.executeQuery(sql);

		Object resFinal = null;
		while (res.next()) {
			resFinal = res.getObject("id_cartao");
		}

		con.close();
		return resFinal;
	}
	
	public static Object BuscarMotivoRecente() throws SQLException, ClassNotFoundException {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url, user, passwd);
		Statement stmt = con.createStatement();
		// buscar pessoa
				
				  sql =
				  "select top 1 * from motivosfraude order by 1 desc"
				  ; ResultSet res2 = stmt.executeQuery(sql);
				 
		ResultSet res = stmt.executeQuery(sql);

		Object resFinal = null;
		while (res.next()) {
			resFinal = res.getObject("id_motivo");
		}

		con.close();
		return resFinal;
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		System.out.println(selecionarConta(null));
	}
	
	public static void atualizarStatusLote(Statement stmt) throws ClassNotFoundException, SQLException {
		criarConexao();
		String idLote = null;
		sql = 	  "UPDATE Lotes"
        		+ "SET StatusLote = 1 "
        		+ "WHERE id_Lote  = "  + idLote  + "";
	    stmt.executeUpdate(sql);
	    encerraConexao(stmt);
	}
	
	public static Object selecionarConta(Statement stmt) throws ClassNotFoundException, SQLException {
		criarConexao();
		Object resFinal = null;
		sql = 	  "SELECT ID_CONTA"
        		+ "FROM CONTAS"
        		+ "WHERE FUNCAOATIVA = 0";
	    ResultSet res = stmt.executeQuery(sql);
	    encerraConexao(stmt);
	    while (res.next()){
	    	resFinal = res.getObject("id_conta");
	    }
	    return resFinal;
	}
	
	
	
	public static void atualizarStatusLote() throws ClassNotFoundException, SQLException {
		Class.forName(driver);	
        Connection con = DriverManager.getConnection(url, user, passwd);
        Statement stmt = con.createStatement();
        Integer idLote = 99999;
		sql = 	  "UPDATE Lotes"
        		+ "SET StatusLote = 1 "
        		+ "WHERE id_Lote  = "  + idLote  + "";
	    stmt.executeQuery(sql);
        con.close();
	}
	
	public static void dropaLotes() throws ClassNotFoundException, SQLException {
		Class.forName(driver);	
        Connection con = DriverManager.getConnection(url, user, passwd);
        Statement stmt = con.createStatement();
        Integer id_solicitante = 1;
		sql = 	  "DELETE FROM Lotes"
        		+ "WHERE id_solicitante  = "  + id_solicitante  + "";
	    stmt.executeQuery(sql);
        con.close();
	}
	
	public static void droparMotivos() throws ClassNotFoundException, SQLException {
		Class.forName(driver);	
        Connection con = DriverManager.getConnection(url, user, passwd);
        Statement stmt = con.createStatement();
		sql = 	  "DELETE from MotivosFraude WHERE id_motivo > 6";
	    stmt.executeUpdate(sql);
        con.close();
	}
}
